package com.productregistration.model;

import com.productregistration.Entity.ImageModel;

import java.io.File;
import java.util.List;

public class FileHandle  {
    private File file;
    private String url;
}
