package com.productregistration.Entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Product  {
    @Id
    @GeneratedValue(strategy =GenerationType.AUTO)
    private Long productid;
     @Column(name = "productName")
    private String productName;
    @Column(name = "quantity_available")
    private int Quantity_available;
    private long price;
    private String category;
     private String modelNO;
     private String noOfDaysUsed;
     private  int yearOfProductSold;
     @ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
     @JoinTable(name = "product_images",
     joinColumns = {
             @JoinColumn(name = "product_id")
     },
     inverseJoinColumns = {
             @JoinColumn(name = "image_id")
     }
     )
     private Set<ImageModel> productImage;

}

