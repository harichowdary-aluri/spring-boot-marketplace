package com.productregistration.Service;

import com.productregistration.Entity.ImageModel;
import com.productregistration.Entity.Product;
import com.productregistration.Repository.ImageRepository;
import com.productregistration.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl  implements ProductService{
    @Autowired
    private ProductRepository productrepository;

    @Autowired
    private ImageRepository imageRepository;

    @Override
    public void saveProduct(Product product) {
        productrepository.save(product);
    }

    @Override
    public void saveImage(ImageModel imageModel) {
        imageRepository.save(imageModel);
    }
    public List<Product> getAllProducts()
    {
      return(List<Product>) productrepository.findAll();
    }

}
