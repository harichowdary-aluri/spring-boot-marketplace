package com.productregistration.Service;

import com.productregistration.Entity.ImageModel;
import com.productregistration.Entity.Product;

import java.util.List;

public interface ProductService {
   public void saveProduct(Product product);

   public void saveImage(ImageModel imageModel);

   public List<Product> getAllProducts();


}
