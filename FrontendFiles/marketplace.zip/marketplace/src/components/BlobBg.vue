<template>
  
</template>

<style lang="scss">
.blobBg {
  position: absolute;
  width: 750px;
  right: -7%;
  bottom: 0;
}
</style>