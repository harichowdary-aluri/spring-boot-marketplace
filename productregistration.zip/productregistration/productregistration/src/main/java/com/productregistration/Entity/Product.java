package com.productregistration.Entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy =GenerationType.AUTO)
    private Long productid;
     @Column(name = "name_of_product")
    private String NameOfProduct;
    @Column(name = "quantity_available")
    private int Quantity_available;
    
    private long price;

    private String catageory;

    private String photos;
}
