package com.productregistration.Service;

import com.productregistration.Entity.Product;
import com.productregistration.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl  implements ProductService{
    @Autowired
    private ProductRepository productrepository;

    @Override
    public Product saveProduct(Product product) {
        return productrepository.save(product);
    }
}
