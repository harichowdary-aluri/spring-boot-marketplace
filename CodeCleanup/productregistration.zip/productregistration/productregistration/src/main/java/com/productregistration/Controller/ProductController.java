package com.productregistration.Controller;

import com.productregistration.Entity.Product;
import com.productregistration.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin("*")
@RestController
public class ProductController {

    @Autowired
    private ProductService productservice;
    @GetMapping
     public String display()
     {
         return "Hello World!";
     }
    @GetMapping("/display")
    public String display1()
    {
        return " This is the sample display";

    }
    @PostMapping("/ProductRegistration")
    public String saveProduct( @Valid @RequestBody Product product) {

        productservice.saveProduct(product);
        return "Your ProductRegistration process has been successfully completd";
    }
}
