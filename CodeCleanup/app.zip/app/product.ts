export interface Product {
    productName: string,
    quantity: number,
    price: number,
    catageory: string,
    photos: string,
    modelNO: string,
    noOfDaysUsed: number,
    yearOfProductSold:number
}