import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductRegistrationService } from '../product-registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  product: Product = {
    productName: "",
    quantity: 0,
    price: 0,
    catageory: "",
    photos: "",
    modelNO: "",
    noOfDaysUsed:0,
    yearOfProductSold:0
  };
  message: any;

  constructor(private service: ProductRegistrationService) { }

  ngOnInit(): void {
  }

  public registerNow() {
    
    let resp = this.service.doRegistration(this.product);
    resp.subscribe((data) => this.message = data)
  }

}
