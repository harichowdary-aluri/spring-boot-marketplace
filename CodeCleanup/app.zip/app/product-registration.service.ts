import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductRegistrationService {

  constructor(private http:HttpClient) { }



 public doRegistration(product: Product){
   return this.http.post("http://localhost:9090/ProductRegistration",product,{responseType:'text' as 'json'});
  }
}
