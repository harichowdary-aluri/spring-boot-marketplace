package com.clone.olx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlxApplicationTests {

	@Test
	void contextLoads() {
	}

}
