package com.clone.olx.enums;

public enum Currency {
    PLN, EUR, USD
}
