package com.clone.olx.enums;

public enum Status {
    available, hidden, sold
}
