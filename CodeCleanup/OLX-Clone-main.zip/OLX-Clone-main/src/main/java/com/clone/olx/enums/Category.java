package com.clone.olx.enums;

public enum Category {
    Cars, Electronics, Sport, Other
}
