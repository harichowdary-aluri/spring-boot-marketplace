import { FileHandle } from "./file-handle";

export interface Product {
    productName: string,
    Quantity_available: number,
    price: number,
    category: string,
    modelNO: string,
    noOfDaysUsed: number,
    yearOfProductSold:number,
    photos: FileHandle[],
}