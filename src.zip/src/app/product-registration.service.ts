import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductRegistrationService {

  constructor(private http:HttpClient) { }



 public doRegistration(product:Product, file:FormData){
    let s = "http://localhost:8080/ProductRegistration?productName=" + product.productName + 
    "&quantityAvailable=" + product.Quantity_available+"&price"+product.price+"&category"+product.category+"&modelNO"+product.modelNO
    "&noOfDaysUsed"+product.noOfDaysUsed+"&yearOfProductSold"+product.yearOfProductSold;
   return this.http.post(s,file,{responseType:'text' as 'json'});
  }
}
