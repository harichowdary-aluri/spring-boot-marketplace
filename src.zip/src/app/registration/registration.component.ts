import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { FileHandle } from '../file-handle';
import { Product } from '../product';
import { ProductRegistrationService } from '../product-registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  product: Product = {
    productName: "",
    Quantity_available: 0,
    price: 0,
    category: "",
    modelNO: "",
    noOfDaysUsed:0,
    yearOfProductSold:0,
    photos: []
  };
  message: any;

  constructor(private service: ProductRegistrationService,
    private sanitizer:DomSanitizer) { }

  ngOnInit(): void {
  }

  public addProduct(productForm:NgForm) {

    const productFD= this.prepareFormData(this.product);
    console.log(this.product);
    let resp = this.service.doRegistration(this.product, productFD);
    resp.subscribe((data) => this.message = data)
  }
    
  prepareFormData(product:Product):FormData{
    const formData = new FormData();
    // formData.append(
    //   'product',
    //   new Blob([JSON.stringify(product)],{type:'application/json'})
    // );
    for (var i=0;i<product.photos.length;i++)
    {
      formData.append(
        'imageFile',
         product.photos[i].file,
         product.photos[i].file.name
      );
    }
    return formData;
    }
  

   OnFileSelected(event:any) {
    if(event.target.file) {
      const file =event.target.files[0];
      const fileHandle:FileHandle={
        file:file,
        url:this.sanitizer.bypassSecurityTrustUrl(
          window.URL.createObjectURL(file)
        ) as string
      }
      this.product.photos.push(fileHandle);
    }
   }
}
