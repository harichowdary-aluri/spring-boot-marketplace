package com.productregistration.Entity;

public class Adi {
}
