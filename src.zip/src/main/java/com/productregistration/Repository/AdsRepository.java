package com.productregistration.Repository;

public class AdsRepository {
}
