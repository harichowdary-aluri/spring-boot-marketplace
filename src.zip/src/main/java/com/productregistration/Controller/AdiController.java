package com.productregistration.Controller;

public class AdiController {
}
