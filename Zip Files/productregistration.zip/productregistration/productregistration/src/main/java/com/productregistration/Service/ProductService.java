package com.productregistration.Service;

import com.productregistration.Entity.Product;

public interface ProductService {
   public Product saveProduct(Product product);
}
